import torch, gc
gc.collect()
# del variables
torch.cuda.empty_cache()